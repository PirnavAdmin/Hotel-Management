using System;
using System.Linq;
using System.Threading.Tasks;
using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/invoices")]
[Route("api/Invoices")]
public class InvoicesController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly ILogger<InvoicesController> _logger;

    public InvoicesController(AppDbContext context, ILogger<InvoicesController> logger)
    {
        _context = context;
        _logger = logger;
    }

    // GET /api/v1/invoices or /api/Invoices
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetInvoices([FromQuery] string? status)
    {
        try
        {
            _logger.LogInformation("Fetching invoices.");
            var query = _context.Invoices.Include(i => i.Payments).AsQueryable();

            if (!string.IsNullOrWhiteSpace(status))
            {
                var statusUpper = status.Trim().ToUpper();
                query = query.Where(i => i.Status.ToUpper() == statusUpper);
            }

            var invoices = await query.OrderByDescending(i => i.CreatedAt).ToListAsync();

            return Ok(new
            {
                success = true,
                message = "Invoices retrieved successfully.",
                count = invoices.Count,
                data = invoices
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred while fetching invoices.");
            return StatusCode(500, new { success = false, message = "An error occurred while retrieving invoices: " + ex.Message });
        }
    }

    // GET /api/v1/invoices/{id} or /api/Invoices/{id}
    [AllowAnonymous]
    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetInvoiceById(long id)
    {
        try
        {
            _logger.LogInformation("Fetching invoice {InvoiceId}", id);
            var invoice = await _context.Invoices.Include(i => i.Payments)
                .FirstOrDefaultAsync(i => i.InvoiceId == id);

            if (invoice == null)
            {
                _logger.LogWarning("Invoice {InvoiceId} not found.", id);
                return NotFound(new { success = false, message = $"Invoice with ID {id} not found." });
            }

            return Ok(new { success = true, data = invoice });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching invoice {InvoiceId}", id);
            return StatusCode(500, new { success = false, message = $"An error occurred while fetching invoice {id}: " + ex.Message });
        }
    }

    // POST /api/v1/invoices or /api/Invoices
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> CreateInvoice([FromBody] CreateInvoiceRequest request)
    {
        if (request == null || request.OrderId <= 0)
        {
            return BadRequest(new { success = false, message = "Valid Order ID is required." });
        }

        try
        {
            _logger.LogInformation("Creating invoice for Order ID {OrderId}", request.OrderId);

            var subtotal = request.Subtotal > 0 ? request.Subtotal : 100.00m;
            var taxableAmount = request.TaxableAmount > 0 ? request.TaxableAmount : (subtotal - request.DiscountAmount);
            if (taxableAmount < 0) taxableAmount = subtotal;

            var invoice = new Invoice
            {
                OrderId = request.OrderId,
                InvoiceNumber = $"INV-{DateTime.UtcNow:yyyyMMdd}-{Random.Shared.Next(1000, 9999)}",
                Subtotal = subtotal,
                TaxableAmount = taxableAmount,
                TaxAmount = request.TaxAmount >= 0 ? request.TaxAmount : (subtotal * 0.05m),
                DiscountAmount = request.DiscountAmount,
                TotalAmount = subtotal + (request.TaxAmount >= 0 ? request.TaxAmount : (subtotal * 0.05m)) - request.DiscountAmount,
                PaidAmount = 0.00m,
                AmountPaid = 0.00m,
                Status = "UNPAID",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Invoices.Add(invoice);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Invoice {InvoiceNumber} created successfully with ID {InvoiceId}.", invoice.InvoiceNumber, invoice.InvoiceId);
            return CreatedAtAction(nameof(GetInvoiceById), new { id = invoice.InvoiceId }, new
            {
                success = true,
                message = "Invoice created successfully.",
                data = invoice
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating invoice for Order ID {OrderId}", request.OrderId);
            return StatusCode(500, new { success = false, message = "An error occurred while creating the invoice: " + ex.Message });
        }
    }

    // POST /api/v1/invoices/{id}/payments or /api/Invoices/{id}/payments
    [AllowAnonymous]
    [HttpPost("{id:long}/payments")]
    public async Task<IActionResult> RecordPayment(long id, [FromBody] RecordPaymentRequest request)
    {
        if (request == null || request.Amount <= 0)
        {
            return BadRequest(new { success = false, message = "Payment amount must be greater than zero." });
        }

        try
        {
            _logger.LogInformation("Recording payment of {Amount} for Invoice ID {InvoiceId}", request.Amount, id);

            var invoice = await _context.Invoices.Include(i => i.Payments)
                .FirstOrDefaultAsync(i => i.InvoiceId == id);

            if (invoice == null)
            {
                _logger.LogWarning("Invoice {InvoiceId} not found for payment recording.", id);
                return NotFound(new { success = false, message = $"Invoice with ID {id} not found." });
            }

            var payment = new InvoicePayment
            {
                InvoiceId = invoice.InvoiceId,
                Amount = request.Amount,
                PaymentMode = string.IsNullOrWhiteSpace(request.PaymentMode) ? "CASH" : request.PaymentMode.Trim().ToUpper(),
                TransactionReference = request.TransactionReference,
                PaidAt = DateTime.UtcNow
            };

            _context.InvoicePayments.Add(payment);

            invoice.PaidAmount += request.Amount;
            invoice.AmountPaid = invoice.PaidAmount;

            if (invoice.PaidAmount >= invoice.TotalAmount)
            {
                invoice.Status = "PAID";
            }
            else if (invoice.PaidAmount > 0)
            {
                invoice.Status = "PARTIAL";
            }
            invoice.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Payment recorded for Invoice {InvoiceId}. New Status: {Status}", id, invoice.Status);
            return Ok(new
            {
                success = true,
                message = "Payment recorded successfully.",
                data = invoice
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error recording payment for Invoice ID {InvoiceId}", id);
            return StatusCode(500, new { success = false, message = "An error occurred while recording payment: " + ex.Message });
        }
    }
}

public class CreateInvoiceRequest
{
    public long OrderId { get; set; }
    public decimal Subtotal { get; set; }
    public decimal TaxableAmount { get; set; }
    public decimal TaxAmount { get; set; }
    public decimal DiscountAmount { get; set; }
}

public class RecordPaymentRequest
{
    public decimal Amount { get; set; }
    public string PaymentMode { get; set; } = "CASH";
    public string? TransactionReference { get; set; }
}
