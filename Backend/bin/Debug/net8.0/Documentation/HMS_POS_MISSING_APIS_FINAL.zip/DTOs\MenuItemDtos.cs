using System.ComponentModel.DataAnnotations;

namespace HMS.DTOs;

public class CreateMenuItemDto
{
    [Required(ErrorMessage = "Dish Name is required.")]
    [MaxLength(100)]
    public string DishName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Category is required.")]
    [MaxLength(100)]
    public string Category { get; set; } = string.Empty;

    [Required(ErrorMessage = "Price is required.")]
    [Range(0.01, 100000.00, ErrorMessage = "Price must be greater than zero.")]
    public decimal Price { get; set; }

    [Required(ErrorMessage = "Dietary Type is required.")]
    [MaxLength(20)]
    public string DietaryType { get; set; } = "Non-Veg";

    [Range(0, 3, ErrorMessage = "Spice level must be between 0 and 3.")]
    public int SpiceLevel { get; set; } = 0;

    public int? PrepTimeMinutes { get; set; } = 15;

    [MaxLength(500)]
    public string? ShortDescription { get; set; }

    [MaxLength(255)]
    public string? ImageUrl { get; set; }

    public bool IsChefsSpecial { get; set; } = false;

    public bool IsAvailable { get; set; } = true;
}

public class UpdateMenuItemDto
{
    [Required(ErrorMessage = "Dish Name is required.")]
    [MaxLength(100)]
    public string DishName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Category is required.")]
    [MaxLength(100)]
    public string Category { get; set; } = string.Empty;

    [Required(ErrorMessage = "Price is required.")]
    [Range(0.01, 100000.00, ErrorMessage = "Price must be greater than zero.")]
    public decimal Price { get; set; }

    [Required(ErrorMessage = "Dietary Type is required.")]
    [MaxLength(20)]
    public string DietaryType { get; set; } = "Non-Veg";

    [Range(0, 3, ErrorMessage = "Spice level must be between 0 and 3.")]
    public int SpiceLevel { get; set; } = 0;

    public int? PrepTimeMinutes { get; set; } = 15;

    [MaxLength(500)]
    public string? ShortDescription { get; set; }

    [MaxLength(255)]
    public string? ImageUrl { get; set; }

    public bool IsChefsSpecial { get; set; } = false;

    public bool IsAvailable { get; set; } = true;
}

public class MenuItemResponseDto
{
    public long MenuItemId { get; set; }

    public string DishName { get; set; } = string.Empty;

    public string Category { get; set; } = string.Empty;

    public decimal Price { get; set; }

    public string DietaryType { get; set; } = string.Empty;

    public int SpiceLevel { get; set; }

    public int? PrepTimeMinutes { get; set; }

    public string? ShortDescription { get; set; }

    public string? ImageUrl { get; set; }

    public bool IsChefsSpecial { get; set; }

    public bool IsAvailable { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime UpdatedAt { get; set; }
}
