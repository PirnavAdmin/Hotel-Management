using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/delivery-orders")]
public class DeliveryController : ControllerBase
{
    private readonly AppDbContext _context;

    public DeliveryController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/delivery-orders
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetDeliveryOrders([FromQuery] string? status)
    {
        var query = _context.DeliveryOrders.AsQueryable();

        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(d => d.DeliveryStatus.ToUpper() == status.Trim().ToUpper());
        }

        var orders = await query.OrderByDescending(d => d.CreatedAt).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Delivery orders retrieved successfully.",
            count = orders.Count,
            data = orders
        });
    }

    // POST /api/v1/delivery-orders
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> CreateDeliveryOrder([FromBody] CreateDeliveryOrderRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.CustomerName) || string.IsNullOrWhiteSpace(request.DeliveryAddress))
        {
            return BadRequest(new { success = false, message = "Customer Name and Delivery Address are required." });
        }

        var delivery = new DeliveryOrder
        {
            OrderId = request.OrderId,
            CustomerName = request.CustomerName.Trim(),
            Phone = request.Phone.Trim(),
            DeliveryAddress = request.DeliveryAddress.Trim(),
            DeliveryStatus = "DISPATCHED",
            CreatedAt = DateTime.UtcNow
        };

        _context.DeliveryOrders.Add(delivery);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Delivery order dispatched successfully.",
            data = delivery
        });
    }

    // PUT /api/v1/delivery-orders/{id}/status
    [AllowAnonymous]
    [HttpPut("{id:long}/status")]
    public async Task<IActionResult> UpdateDeliveryStatus(long id, [FromBody] UpdateDeliveryStatusRequest request)
    {
        var delivery = await _context.DeliveryOrders.FirstOrDefaultAsync(d => d.DeliveryId == id);

        if (delivery == null)
        {
            return NotFound(new { success = false, message = $"Delivery Order with ID {id} not found." });
        }

        if (string.IsNullOrWhiteSpace(request.Status))
        {
            return BadRequest(new { success = false, message = "Status is required." });
        }

        delivery.DeliveryStatus = request.Status.Trim().ToUpper();
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Delivery status updated successfully.",
            data = delivery
        });
    }
}

public class CreateDeliveryOrderRequest
{
    public long OrderId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string DeliveryAddress { get; set; } = string.Empty;
}

public class UpdateDeliveryStatusRequest
{
    public string Status { get; set; } = "DELIVERED";
}
