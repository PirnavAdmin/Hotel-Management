﻿using HMS.Data;
using HMS.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/roles")]
[Authorize]
public class RolesController : ControllerBase
{
    private readonly AppDbContext _context;

    public RolesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAllRoles()
    {
        var roles = await _context.Roles
            .Where(r =>
                r.IsActive &&
                r.DeletedAt == null)
            .OrderBy(r => r.RoleId)
            .Select(r => new RoleResponseDto
            {
                RoleId = r.RoleId,
                RoleName = r.RoleName,
                Description = r.Description,
                IsActive = r.IsActive
            })
            .ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Roles retrieved successfully.",
            data = roles
        });
    }

    [HttpGet("{roleId:long}")]
    public async Task<IActionResult> GetRoleById(long roleId)
    {
        var role = await _context.Roles
            .Where(r =>
                r.RoleId == roleId &&
                r.DeletedAt == null)
            .Select(r => new RoleResponseDto
            {
                RoleId = r.RoleId,
                RoleName = r.RoleName,
                Description = r.Description,
                IsActive = r.IsActive
            })
            .FirstOrDefaultAsync();

        if (role == null)
        {
            return NotFound(new
            {
                success = false,
                message = "Role not found."
            });
        }

        return Ok(new
        {
            success = true,
            message = "Role retrieved successfully.",
            data = role
        });
    }
}