using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/promotions")]
public class PromotionsController : ControllerBase
{
    private readonly AppDbContext _context;

    public PromotionsController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/promotions
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetPromotions()
    {
        var promotions = await _context.Promotions.Where(p => p.IsActive).OrderByDescending(p => p.ValidUntil).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Promotions retrieved successfully.",
            count = promotions.Count,
            data = promotions
        });
    }

    // POST /api/v1/promotions
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> CreatePromotion([FromBody] CreatePromotionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Code))
        {
            return BadRequest(new { success = false, message = "Promotion Code is required." });
        }

        var promotion = new Promotion
        {
            Code = request.Code.Trim().ToUpper(),
            DiscountPercentage = request.DiscountPercentage,
            FlatDiscount = request.FlatDiscount,
            ValidUntil = request.ValidUntil != default ? request.ValidUntil : DateTime.UtcNow.AddDays(30),
            IsActive = true
        };

        _context.Promotions.Add(promotion);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Promotion code created successfully.",
            data = promotion
        });
    }
}

public class CreatePromotionRequest
{
    public string Code { get; set; } = string.Empty;
    public decimal DiscountPercentage { get; set; }
    public decimal FlatDiscount { get; set; }
    public DateTime ValidUntil { get; set; }
}
