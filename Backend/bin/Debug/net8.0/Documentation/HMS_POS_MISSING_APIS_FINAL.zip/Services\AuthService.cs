using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace HMS.Services;

public class AuthService
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;

    public AuthService(
        AppDbContext context,
        IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    // ============================================================
    // REGISTER
    // ============================================================

    public async Task<RegisterResponseDto> RegisterAsync(
        RegisterRequestDto request)
    {
        if (request.Password != request.ConfirmPassword)
        {
            return new RegisterResponseDto
            {
                Success = false,
                Message = "Password and confirm password do not match."
            };
        }

        var fullName = request.FullName.Trim();
        var username = request.UserName.Trim();
        var email = request.Email.Trim().ToLower();

        var usernameExists = await _context.Users
            .AnyAsync(u =>
                u.UserName.ToLower() == username.ToLower() &&
                u.DeletedAt == null);

        if (usernameExists)
        {
            return new RegisterResponseDto
            {
                Success = false,
                Message = "Username already exists."
            };
        }

        var emailExists = await _context.Users
            .AnyAsync(u =>
                u.Email.ToLower() == email &&
                u.DeletedAt == null);

        if (emailExists)
        {
            return new RegisterResponseDto
            {
                Success = false,
                Message = "Email already exists."
            };
        }

        // Find specified role or default to Admin role for Admin Portal registration
        Role? role = null;
        if (request.RoleId.HasValue && request.RoleId.Value > 0)
        {
            role = await _context.Roles
                .FirstOrDefaultAsync(r =>
                    r.RoleId == request.RoleId.Value &&
                    r.IsActive &&
                    r.DeletedAt == null);
        }
        else
        {
            role = await _context.Roles
                .FirstOrDefaultAsync(r =>
                    r.RoleName == "Admin" &&
                    r.IsActive &&
                    r.DeletedAt == null)
                ?? await _context.Roles
                .FirstOrDefaultAsync(r =>
                    r.IsActive &&
                    r.DeletedAt == null);
        }

        if (role == null)
        {
            return new RegisterResponseDto
            {
                Success = false,
                Message = "No active role found for admin account registration."
            };
        }

        var passwordHash =
            BCrypt.Net.BCrypt.HashPassword(request.Password);

        var user = new User
        {
            RoleId = role.RoleId,

            BranchId = request.BranchId,

            FullName = fullName,

            UserName = username,

            Password = request.Password,

            ConfirmPassword = request.ConfirmPassword,

            PasswordHash = passwordHash,

            Email = email,

            Phone = request.Phone,

            PinCode = request.PinCode,

            IsActive = true,

            CreatedAt = DateTime.UtcNow,

            UpdatedAt = DateTime.UtcNow
        };

        _context.Users.Add(user);

        await _context.SaveChangesAsync();

        return new RegisterResponseDto
        {
            Success = true,

            Message = "Admin account created successfully.",

            User = new UserRegisterDto
            {
                UserId = user.UserId,

                FullName = user.FullName,

                UserName = user.UserName,

                Email = user.Email,

                Phone = user.Phone,

                RoleId = user.RoleId,

                RoleName = role.RoleName,

                BranchId = user.BranchId,

                IsActive = user.IsActive
            }
        };
    }

    // ============================================================
    // LOGIN
    // ============================================================

    public async Task<LoginResponseDto> LoginAsync(
        LoginRequestDto request)
    {
        var loginValue =
            request.UsernameOrEmail.Trim();

        var user = await _context.Users
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u =>
                u.DeletedAt == null &&
                (
                    u.UserName.ToLower() ==
                    loginValue.ToLower()

                    ||

                    u.Email.ToLower() ==
                    loginValue.ToLower()
                ));

        if (user == null)
        {
            return new LoginResponseDto
            {
                Success = false,
                Message = "Invalid username/email or password."
            };
        }

        if (!user.IsActive)
        {
            return new LoginResponseDto
            {
                Success = false,
                Message = "User account is inactive."
            };
        }

        if (user.Role == null ||
            !user.Role.IsActive ||
            user.Role.DeletedAt != null)
        {
            return new LoginResponseDto
            {
                Success = false,
                Message = "User role is inactive."
            };
        }

        // IMPORTANT:
        // Login verifies the BCrypt hash.
        var passwordValid =
            BCrypt.Net.BCrypt.Verify(
                request.Password,
                user.PasswordHash);

        if (!passwordValid)
        {
            return new LoginResponseDto
            {
                Success = false,
                Message = "Invalid username/email or password."
            };
        }

        user.LastLogin = DateTime.UtcNow;

        user.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        var token =
            GenerateJwtToken(user);

        return new LoginResponseDto
        {
            Success = true,

            Message = "Login successful.",

            Token = token,

            User = new UserLoginDto
            {
                UserId = user.UserId,

                FullName = user.FullName ?? user.UserName,

                UserName = user.UserName,

                Email = user.Email,

                Phone = user.Phone,

                RoleId = user.RoleId,

                RoleName = user.Role.RoleName,

                BranchId = user.BranchId
            }
        };
    }

    // ============================================================
    // SEND OTP (For Registration & Password Reset)
    // ============================================================

    public async Task<object> SendOtpAsync(
        SendOtpRequestDto request)
    {
        var email = request.Email.Trim().ToLower();

        // Generate 6-digit OTP code
        var otp = RandomNumberGenerator
            .GetInt32(100000, 1000000)
            .ToString();

        var otpHash = BCrypt.Net.BCrypt.HashPassword(otp);

        var user = await _context.Users
            .FirstOrDefaultAsync(u =>
                u.Email.ToLower() == email &&
                u.DeletedAt == null);

        if (user != null)
        {
            var previousTokens = await _context.PasswordResetTokens
                .Where(x => x.UserId == user.UserId && x.UsedAt == null)
                .ToListAsync();

            foreach (var token in previousTokens)
            {
                token.UsedAt = DateTime.UtcNow;
            }

            var resetToken = new PasswordResetToken
            {
                UserId = user.UserId,
                OtpHash = otpHash,
                ExpiresAt = DateTime.UtcNow.AddMinutes(10),
                Attempts = 0,
                CreatedAt = DateTime.UtcNow
            };

            _context.PasswordResetTokens.Add(resetToken);
            await _context.SaveChangesAsync();
        }

        return new
        {
            success = true,
            message = "OTP generated successfully.",
            email = email,
            otp = otp, // Dev mode testing
            expiresInMinutes = 10
        };
    }

    // ============================================================
    // FORGOT PASSWORD
    // ============================================================

    public async Task<object> ForgotPasswordAsync(
        ForgotPasswordRequestDto request)
    {
        var email =
            request.Email.Trim().ToLower();

        var user = await _context.Users
            .FirstOrDefaultAsync(u =>
                u.Email.ToLower() == email &&
                u.IsActive &&
                u.DeletedAt == null);

        if (user == null)
        {
            return new
            {
                success = false,
                message = "User with this email was not found."
            };
        }

        // Invalidate previous OTPs
        var previousTokens =
            await _context.PasswordResetTokens
                .Where(x =>
                    x.UserId == user.UserId &&
                    x.UsedAt == null)
                .ToListAsync();

        foreach (var token in previousTokens)
        {
            token.UsedAt = DateTime.UtcNow;
        }

        // Generate secure 6-digit OTP
        var otp =
            RandomNumberGenerator
                .GetInt32(100000, 1000000)
                .ToString();

        var otpHash =
            BCrypt.Net.BCrypt.HashPassword(otp);

        var resetToken =
            new PasswordResetToken
            {
                UserId = user.UserId,

                OtpHash = otpHash,

                ExpiresAt =
                    DateTime.UtcNow.AddMinutes(10),

                Attempts = 0,

                CreatedAt = DateTime.UtcNow
            };

        _context.PasswordResetTokens
            .Add(resetToken);

        await _context.SaveChangesAsync();

        return new
        {
            success = true,

            message =
                "OTP generated successfully.",

            email = user.Email,

            // Development only.
            // Remove this when email/SMS is integrated.
            otp = otp,

            expiresInMinutes = 10
        };
    }

    // ============================================================
    // VERIFY OTP
    // ============================================================

    public async Task<object> VerifyOtpAsync(
        VerifyOtpRequestDto request)
    {
        var email =
            request.Email.Trim().ToLower();

        var user = await _context.Users
            .FirstOrDefaultAsync(u =>
                u.Email.ToLower() == email &&
                u.IsActive &&
                u.DeletedAt == null);

        if (user == null)
        {
            return new
            {
                success = false,
                message = "User not found."
            };
        }

        var resetToken =
            await _context.PasswordResetTokens
                .Where(x =>
                    x.UserId == user.UserId &&
                    x.UsedAt == null)
                .OrderByDescending(x => x.CreatedAt)
                .FirstOrDefaultAsync();

        if (resetToken == null)
        {
            return new
            {
                success = false,
                message = "No active OTP found."
            };
        }

        if (DateTime.UtcNow >
            resetToken.ExpiresAt)
        {
            return new
            {
                success = false,
                message = "OTP has expired."
            };
        }

        if (resetToken.Attempts >= 5)
        {
            return new
            {
                success = false,
                message =
                    "Maximum OTP attempts exceeded."
            };
        }

        var validOtp =
            BCrypt.Net.BCrypt.Verify(
                request.Otp,
                resetToken.OtpHash);

        if (!validOtp)
        {
            resetToken.Attempts++;

            await _context.SaveChangesAsync();

            return new
            {
                success = false,
                message = "Invalid OTP."
            };
        }

        resetToken.VerifiedAt =
            DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return new
        {
            success = true,
            message =
                "OTP verified successfully."
        };
    }

    // ============================================================
    // RESET PASSWORD
    // ============================================================

    public async Task<object> ResetPasswordAsync(
        ResetPasswordRequestDto request)
    {
        if (request.NewPassword !=
            request.ConfirmPassword)
        {
            return new
            {
                success = false,
                message =
                    "New password and confirm password do not match."
            };
        }

        var email =
            request.Email.Trim().ToLower();

        var user = await _context.Users
            .FirstOrDefaultAsync(u =>
                u.Email.ToLower() == email &&
                u.IsActive &&
                u.DeletedAt == null);

        if (user == null)
        {
            return new
            {
                success = false,
                message = "User not found."
            };
        }

        var resetToken =
            await _context.PasswordResetTokens
                .Where(x =>
                    x.UserId == user.UserId &&
                    x.UsedAt == null)
                .OrderByDescending(x => x.CreatedAt)
                .FirstOrDefaultAsync();

        if (resetToken == null)
        {
            return new
            {
                success = false,
                message =
                    "No active password reset request found."
            };
        }

        if (DateTime.UtcNow >
            resetToken.ExpiresAt)
        {
            return new
            {
                success = false,
                message = "OTP has expired."
            };
        }

        if (resetToken.VerifiedAt == null)
        {
            return new
            {
                success = false,
                message =
                    "Please verify the OTP first."
            };
        }

        var validOtp =
            BCrypt.Net.BCrypt.Verify(
                request.Otp,
                resetToken.OtpHash);

        if (!validOtp)
        {
            return new
            {
                success = false,
                message = "Invalid OTP."
            };
        }

        // ========================================================
        // UPDATE PASSWORD
        // ========================================================

        user.Password =
            request.NewPassword;

        user.ConfirmPassword =
            request.ConfirmPassword;

        user.PasswordHash =
            BCrypt.Net.BCrypt.HashPassword(
                request.NewPassword);

        user.UpdatedAt =
            DateTime.UtcNow;

        // OTP cannot be reused
        resetToken.UsedAt =
            DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return new
        {
            success = true,
            message =
                "Password reset successfully."
        };
    }

    // ============================================================
    // GENERATE JWT
    // ============================================================

    private string GenerateJwtToken(User user)
    {
        var jwtKey =
            _configuration["Jwt:Key"];

        var jwtIssuer =
            _configuration["Jwt:Issuer"];

        var jwtAudience =
            _configuration["Jwt:Audience"];

        var expiryMinutes =
            int.TryParse(
                _configuration["Jwt:ExpiryMinutes"],
                out var minutes)
                ? minutes
                : 60;

        if (string.IsNullOrWhiteSpace(jwtKey))
        {
            throw new InvalidOperationException(
                "JWT key is missing.");
        }

        var claims =
            new List<Claim>
            {
                new Claim(
                    JwtRegisteredClaimNames.Sub,
                    user.UserId.ToString()),

                new Claim(
                    ClaimTypes.Name,
                    user.UserName),

                new Claim(
                    JwtRegisteredClaimNames.UniqueName,
                    user.UserName),

                new Claim(
                    ClaimTypes.Email,
                    user.Email),

                new Claim(
                    ClaimTypes.Role,
                    user.Role?.RoleName ?? string.Empty),

                new Claim(
                    "fullName",
                    user.FullName ?? user.UserName),

                new Claim(
                    "userId",
                    user.UserId.ToString()),

                new Claim(
                    "roleId",
                    user.RoleId.ToString()),

                new Claim(
                    "roleName",
                    user.Role?.RoleName ?? string.Empty),

                new Claim(
                    "branchId",
                    user.BranchId?.ToString() ?? "")
            };

        var key =
            new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwtKey));

        var credentials =
            new SigningCredentials(
                key,
                SecurityAlgorithms.HmacSha256);

        var token =
            new JwtSecurityToken(
                issuer: jwtIssuer,
                audience: jwtAudience,
                claims: claims,
                expires:
                    DateTime.UtcNow.AddMinutes(
                        expiryMinutes),
                signingCredentials:
                    credentials);

        return new JwtSecurityTokenHandler()
            .WriteToken(token);
    }
}