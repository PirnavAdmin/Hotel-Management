using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS.Services;

public class TableService
{
    private readonly AppDbContext _context;

    public TableService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<TableResponseDto>> GetTablesAsync(string? section = null, string? status = null)
    {
        var query = _context.RestaurantTables
            .Include(t => t.AssignedServer)
            .Where(t => t.DeletedAt == null)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(section))
        {
            var sectionLower = section.Trim().ToLower();
            query = query.Where(t => t.SectionArea.ToLower() == sectionLower);
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            var statusUpper = status.Trim().ToUpper();
            query = query.Where(t => t.Status.ToUpper() == statusUpper);
        }

        var tables = await query
            .OrderBy(t => t.TableId)
            .ToListAsync();

        return tables.Select(MapToResponseDto).ToList();
    }

    public async Task<TableSummaryDto> GetTableSummaryAsync()
    {
        var tables = await _context.RestaurantTables
            .Where(t => t.DeletedAt == null)
            .ToListAsync();

        var totalTables = tables.Count;
        var totalChairs = tables.Sum(t => t.CapacityChairs);
        var occupiedChairs = tables.Sum(t => t.OccupiedChairs);
        var availableChairs = totalChairs - occupiedChairs;

        return new TableSummaryDto
        {
            TotalTables = totalTables,
            TotalChairs = totalChairs,
            OccupiedChairs = occupiedChairs,
            AvailableChairs = availableChairs > 0 ? availableChairs : 0
        };
    }

    public async Task<TableResponseDto?> GetTableByIdAsync(long id)
    {
        var table = await _context.RestaurantTables
            .Include(t => t.AssignedServer)
            .FirstOrDefaultAsync(t => t.TableId == id && t.DeletedAt == null);

        return table == null ? null : MapToResponseDto(table);
    }

    public async Task<TableResponseDto> CreateTableAsync(CreateTableDto dto)
    {
        var table = new RestaurantTable
        {
            TableName = dto.TableName.Trim(),
            SectionArea = dto.SectionArea.Trim(),
            CapacityChairs = dto.CapacityChairs,
            OccupiedChairs = 0,
            Status = "VACANT",
            AssignedServerId = dto.AssignedServerId,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.RestaurantTables.Add(table);
        await _context.SaveChangesAsync();

        if (table.AssignedServerId.HasValue)
        {
            await _context.Entry(table)
                .Reference(t => t.AssignedServer)
                .LoadAsync();
        }

        return MapToResponseDto(table);
    }

    public async Task<TableResponseDto?> UpdateTableAsync(long id, UpdateTableDto dto)
    {
        var table = await _context.RestaurantTables
            .Include(t => t.AssignedServer)
            .FirstOrDefaultAsync(t => t.TableId == id && t.DeletedAt == null);

        if (table == null) return null;

        table.TableName = dto.TableName.Trim();
        table.SectionArea = dto.SectionArea.Trim();
        table.CapacityChairs = dto.CapacityChairs;
        table.OccupiedChairs = dto.OccupiedChairs;
        table.Status = dto.Status.Trim().ToUpper();
        table.AssignedServerId = dto.AssignedServerId;
        table.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        if (table.AssignedServerId.HasValue)
        {
            await _context.Entry(table)
                .Reference(t => t.AssignedServer)
                .LoadAsync();
        }

        return MapToResponseDto(table);
    }

    public async Task<bool> DeleteTableAsync(long id)
    {
        var table = await _context.RestaurantTables
            .FirstOrDefaultAsync(t => t.TableId == id && t.DeletedAt == null);

        if (table == null) return false;

        table.DeletedAt = DateTime.UtcNow;
        table.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<(bool Success, string Message)> TransferTableAsync(long sourceTableId, long targetTableId)
    {
        if (sourceTableId == targetTableId)
        {
            return (false, "Source and target table cannot be the same.");
        }

        using var transaction = await _context.Database.BeginTransactionAsync();
        try
        {
            var activeOrder = await _context.Orders
                .FirstOrDefaultAsync(o => o.TableId == sourceTableId && !o.IsDeleted && o.Status == "Active");

            if (activeOrder == null)
            {
                return (false, $"No active order found on Table {sourceTableId}.");
            }

            var targetOrder = await _context.Orders
                .FirstOrDefaultAsync(o => o.TableId == targetTableId && !o.IsDeleted && o.Status == "Active");

            if (targetOrder != null)
            {
                return (false, $"Target Table {targetTableId} already has an active order (Double booking prevented).");
            }

            var targetTable = await _context.DiningTables.FirstOrDefaultAsync(t => t.Id == targetTableId);
            string targetName = targetTable != null ? targetTable.Name : $"Table {targetTableId}";

            // Update Order Table Assignment
            activeOrder.TableId = targetTableId;
            activeOrder.TableName = targetName;
            activeOrder.UpdatedAt = DateTime.UtcNow;

            // Update Table Statuses
            var sourceTableObj = await _context.DiningTables.FirstOrDefaultAsync(t => t.Id == sourceTableId);
            if (sourceTableObj != null)
            {
                sourceTableObj.Status = "Vacant";
                sourceTableObj.UpdatedAt = DateTime.UtcNow;
            }

            if (targetTable != null)
            {
                targetTable.Status = "Occupied";
                targetTable.UpdatedAt = DateTime.UtcNow;
            }

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            return (true, $"Order successfully transferred from Table {sourceTableId} to Table {targetTableId}.");
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            return (false, $"Failed to transfer table: {ex.Message}");
        }
    }

    private static TableResponseDto MapToResponseDto(RestaurantTable t)
    {
        return new TableResponseDto
        {
            TableId = t.TableId,
            TableName = t.TableName,
            SectionArea = t.SectionArea,
            CapacityChairs = t.CapacityChairs,
            OccupiedChairs = t.OccupiedChairs,
            Status = t.Status,
            AssignedServerId = t.AssignedServerId,
            AssignedServerName = t.AssignedServer?.FullName,
            AssignedServerRole = t.AssignedServer?.RoleTitle,
            CreatedAt = t.CreatedAt
        };
    }
}
