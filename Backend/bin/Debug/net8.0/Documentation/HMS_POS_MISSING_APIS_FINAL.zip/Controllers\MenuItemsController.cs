using HMS.DTOs;
using HMS.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/menu-items")]
[Route("api/Menu")]
public class MenuItemsController : ControllerBase
{
    private readonly MenuItemService _menuItemService;

    public MenuItemsController(MenuItemService menuItemService)
    {
        _menuItemService = menuItemService;
    }

    // GET /api/v1/menu-items or /api/Menu
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetMenuItems([FromQuery] string? search, [FromQuery] string? category, [FromQuery] string? dietaryType)
    {
        var items = await _menuItemService.GetMenuItemsAsync(search, category, dietaryType);
        return Ok(new
        {
            success = true,
            message = "Menu items retrieved successfully.",
            count = items.Count,
            data = items
        });
    }

    // GET /api/v1/menu-items/categories or /api/Menu/categories
    [AllowAnonymous]
    [HttpGet("categories")]
    public async Task<IActionResult> GetCategories()
    {
        var categories = await _menuItemService.GetCategoriesAsync();
        return Ok(new
        {
            success = true,
            data = categories
        });
    }

    // POST /api/v1/menu-items/categories or /api/Menu/categories
    [Authorize]
    [HttpPost("categories")]
    public async Task<IActionResult> CreateCategory([FromBody] CreateCategoryRequest request)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(new { success = false, message = "Invalid category data.", errors = ModelState });
        }

        var created = await _menuItemService.CreateCategoryAsync(request);
        return Ok(new
        {
            success = true,
            message = "Category created successfully.",
            data = created
        });
    }

    // GET /api/v1/menu-items/{id}
    [AllowAnonymous]
    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetMenuItemById(long id)
    {
        var item = await _menuItemService.GetMenuItemByIdAsync(id);
        if (item == null)
        {
            return NotFound(new { success = false, message = $"Menu item with ID {id} not found." });
        }
        return Ok(new { success = true, data = item });
    }

    // POST /api/v1/menu-items or /api/Menu/items
    [Authorize]
    [HttpPost]
    [HttpPost("items")]
    public async Task<IActionResult> CreateMenuItem([FromBody] CreateMenuItemDto dto)
    {
        var created = await _menuItemService.CreateMenuItemAsync(dto);
        return CreatedAtAction(nameof(GetMenuItemById), new { id = created.MenuItemId }, new
        {
            success = true,
            message = "Menu item created successfully.",
            data = created
        });
    }

    // PUT /api/v1/menu-items/{id} or /api/Menu/items/{id}
    [Authorize]
    [HttpPut("{id:long}")]
    [HttpPut("items/{id:long}")]
    public async Task<IActionResult> UpdateMenuItem(long id, [FromBody] UpdateMenuItemDto dto)
    {
        var updated = await _menuItemService.UpdateMenuItemAsync(id, dto);
        if (updated == null)
        {
            return NotFound(new { success = false, message = $"Menu item with ID {id} not found." });
        }
        return Ok(new
        {
            success = true,
            message = "Menu item updated successfully.",
            data = updated
        });
    }

    // PATCH /api/v1/menu-items/{id}/availability or /api/Menu/items/{id}/availability
    [Authorize]
    [HttpPatch("{id:long}/availability")]
    [HttpPatch("items/{id:long}/availability")]
    public async Task<IActionResult> ToggleAvailability(long id, [FromBody] ToggleAvailabilityRequest request)
    {
        var updated = await _menuItemService.ToggleAvailabilityAsync(id, request.IsAvailable);
        if (updated == null)
        {
            return NotFound(new { success = false, message = $"Menu item with ID {id} not found." });
        }
        return Ok(new
        {
            success = true,
            message = $"Availability for menu item {id} updated to {request.IsAvailable}.",
            data = updated
        });
    }

    // DELETE /api/v1/menu-items/{id} or /api/Menu/items/{id}
    [Authorize]
    [HttpDelete("{id:long}")]
    [HttpDelete("items/{id:long}")]
    public async Task<IActionResult> DeleteMenuItem(long id)
    {
        var success = await _menuItemService.DeleteMenuItemAsync(id);
        if (!success)
        {
            return NotFound(new { success = false, message = $"Menu item with ID {id} not found." });
        }
        return Ok(new { success = true, message = "Menu item deleted successfully." });
    }
}
