using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS.Services;

public class StaffService
{
    private readonly AppDbContext _context;

    public StaffService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<StaffResponseDto>> GetStaffListAsync()
    {
        var staffList = await _context.StaffPersons
            .Include(s => s.AssignedTables.Where(t => t.DeletedAt == null))
            .Where(s => s.DeletedAt == null)
            .OrderBy(s => s.StaffId)
            .ToListAsync();

        return staffList.Select(MapToResponseDto).ToList();
    }

    public async Task<StaffResponseDto?> GetStaffByIdAsync(long id)
    {
        var staff = await _context.StaffPersons
            .Include(s => s.AssignedTables.Where(t => t.DeletedAt == null))
            .FirstOrDefaultAsync(s => s.StaffId == id && s.DeletedAt == null);

        return staff == null ? null : MapToResponseDto(staff);
    }

    public async Task<StaffResponseDto> CreateStaffAsync(CreateStaffDto dto)
    {
        var staff = new StaffPerson
        {
            FullName = dto.FullName.Trim(),
            RoleTitle = dto.RoleTitle.Trim(),
            Phone = dto.Phone.Trim(),
            Shift = dto.Shift.Trim(),
            IsActive = dto.IsActive,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.StaffPersons.Add(staff);
        await _context.SaveChangesAsync();

        return MapToResponseDto(staff);
    }

    public async Task<StaffResponseDto?> UpdateStaffAsync(long id, UpdateStaffDto dto)
    {
        var staff = await _context.StaffPersons
            .Include(s => s.AssignedTables.Where(t => t.DeletedAt == null))
            .FirstOrDefaultAsync(s => s.StaffId == id && s.DeletedAt == null);

        if (staff == null) return null;

        staff.FullName = dto.FullName.Trim();
        staff.RoleTitle = dto.RoleTitle.Trim();
        staff.Phone = dto.Phone.Trim();
        staff.Shift = dto.Shift.Trim();
        staff.IsActive = dto.IsActive;
        staff.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return MapToResponseDto(staff);
    }

    public async Task<bool> DeleteStaffAsync(long id)
    {
        var staff = await _context.StaffPersons
            .FirstOrDefaultAsync(s => s.StaffId == id && s.DeletedAt == null);

        if (staff == null) return false;

        staff.DeletedAt = DateTime.UtcNow;
        staff.UpdatedAt = DateTime.UtcNow;

        // Unassign server from any tables
        var tables = await _context.RestaurantTables
            .Where(t => t.AssignedServerId == id)
            .ToListAsync();

        foreach (var t in tables)
        {
            t.AssignedServerId = null;
        }

        await _context.SaveChangesAsync();
        return true;
    }

    private static StaffResponseDto MapToResponseDto(StaffPerson s)
    {
        var nameParts = s.FullName.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var initial = nameParts.Length > 0 ? nameParts[0][0].ToString().ToUpper() : "S";

        return new StaffResponseDto
        {
            StaffId = s.StaffId,
            FullName = s.FullName,
            RoleTitle = s.RoleTitle,
            Phone = s.Phone,
            Shift = s.Shift,
            IsActive = s.IsActive,
            AssignedTablesCount = s.AssignedTables?.Count ?? 0,
            AvatarInitial = initial,
            CreatedAt = s.CreatedAt
        };
    }
}
