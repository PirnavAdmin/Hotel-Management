using HMS.DTOs;
using HMS.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/staff")]
[Route("api/Staff")]
public class StaffController : ControllerBase
{
    private readonly StaffService _staffService;

    public StaffController(StaffService staffService)
    {
        _staffService = staffService;
    }

    // GET /api/v1/staff
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetStaffList()
    {
        var staffList = await _staffService.GetStaffListAsync();
        return Ok(new
        {
            success = true,
            message = "Staff members retrieved successfully.",
            count = staffList.Count,
            data = staffList
        });
    }

    // GET /api/v1/staff/{id}
    [AllowAnonymous]
    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetStaffById(long id)
    {
        var staff = await _staffService.GetStaffByIdAsync(id);
        if (staff == null)
        {
            return NotFound(new { success = false, message = $"Staff member with ID {id} not found." });
        }
        return Ok(new { success = true, data = staff });
    }

    // POST /api/v1/staff
    [Authorize]
    [HttpPost]
    public async Task<IActionResult> CreateStaff([FromBody] CreateStaffDto dto)
    {
        var created = await _staffService.CreateStaffAsync(dto);
        return CreatedAtAction(nameof(GetStaffById), new { id = created.StaffId }, new
        {
            success = true,
            message = "Staff member added successfully.",
            data = created
        });
    }

    // PUT /api/v1/staff/{id}
    [Authorize]
    [HttpPut("{id:long}")]
    public async Task<IActionResult> UpdateStaff(long id, [FromBody] UpdateStaffDto dto)
    {
        var updated = await _staffService.UpdateStaffAsync(id, dto);
        if (updated == null)
        {
            return NotFound(new { success = false, message = $"Staff member with ID {id} not found." });
        }
        return Ok(new
        {
            success = true,
            message = "Staff member updated successfully.",
            data = updated
        });
    }

    // DELETE /api/v1/staff/{id}
    [Authorize]
    [HttpDelete("{id:long}")]
    public async Task<IActionResult> DeleteStaff(long id)
    {
        var success = await _staffService.DeleteStaffAsync(id);
        if (!success)
        {
            return NotFound(new { success = false, message = $"Staff member with ID {id} not found." });
        }
        return Ok(new { success = true, message = "Staff member removed successfully." });
    }
}
