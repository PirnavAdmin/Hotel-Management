using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS.Services;

public class LoginManagementService
{
    private readonly AppDbContext _context;

    public LoginManagementService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<LoginManagementSummaryDto> GetLoginManagementSummaryAsync()
    {
        var users = await _context.Users
            .Include(u => u.Role)
            .Where(u => u.DeletedAt == null)
            .OrderByDescending(u => u.CreatedAt)
            .ToListAsync();

        var posUsers = users
            .Where(u => u.Role != null && (u.Role.RoleName == "User POS" || u.Role.RoleName.Contains("POS")))
            .Select(MapToUserAccountDto)
            .ToList();

        var kotUsers = users
            .Where(u => u.Role != null && (u.Role.RoleName == "Kitchen KOT" || u.Role.RoleName.Contains("KOT")))
            .Select(MapToUserAccountDto)
            .ToList();

        var admins = users
            .Where(u => u.Role != null && u.Role.RoleName == "Admin")
            .Select(MapToUserAccountDto)
            .ToList();

        return new LoginManagementSummaryDto
        {
            PosUsersCount = posUsers.Count,
            KotUsersCount = kotUsers.Count,
            AdminsCount = admins.Count,
            PosUsers = posUsers,
            KotUsers = kotUsers,
            Admins = admins
        };
    }

    public async Task<object> CreateLoginAsync(CreateLoginDto dto)
    {
        var username = dto.UserName.Trim();
        var roleNameInput = dto.AccountRole.Trim();

        var usernameExists = await _context.Users
            .AnyAsync(u => u.UserName.ToLower() == username.ToLower() && u.DeletedAt == null);

        if (usernameExists)
        {
            return new { success = false, message = "Username already exists." };
        }

        // Map input role name to DB Role
        var targetRoleName = roleNameInput.Contains("POS", StringComparison.OrdinalIgnoreCase) ? "User POS" :
                             roleNameInput.Contains("KOT", StringComparison.OrdinalIgnoreCase) ? "Kitchen KOT" :
                             roleNameInput;

        var role = await _context.Roles
            .FirstOrDefaultAsync(r => r.RoleName.ToLower() == targetRoleName.ToLower() && r.IsActive && r.DeletedAt == null);

        if (role == null)
        {
            return new { success = false, message = $"Role '{dto.AccountRole}' not found or inactive." };
        }

        var passwordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password);
        var email = !string.IsNullOrWhiteSpace(dto.Email) ? dto.Email.Trim().ToLower() : $"{username.ToLower()}@avsrfoodcourt.com";

        var user = new User
        {
            RoleId = role.RoleId,
            FullName = dto.DisplayName.Trim(),
            UserName = username,
            Password = dto.Password,
            ConfirmPassword = dto.Password,
            PasswordHash = passwordHash,
            Email = email,
            Phone = dto.Phone?.Trim(),
            IsActive = true,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return new
        {
            success = true,
            message = $"{role.RoleName} account created successfully.",
            user = MapToUserAccountDto(user, role.RoleName)
        };
    }

    private static UserAccountDto MapToUserAccountDto(User u)
    {
        return new UserAccountDto
        {
            UserId = u.UserId,
            FullName = !string.IsNullOrWhiteSpace(u.FullName) ? u.FullName : u.UserName,
            UserName = u.UserName,
            Email = u.Email,
            Phone = u.Phone,
            RoleId = u.RoleId,
            RoleName = u.Role?.RoleName ?? "User",
            IsActive = u.IsActive,
            CreatedAt = u.CreatedAt,
            LastLogin = u.LastLogin
        };
    }

    private static UserAccountDto MapToUserAccountDto(User u, string roleName)
    {
        return new UserAccountDto
        {
            UserId = u.UserId,
            FullName = !string.IsNullOrWhiteSpace(u.FullName) ? u.FullName : u.UserName,
            UserName = u.UserName,
            Email = u.Email,
            Phone = u.Phone,
            RoleId = u.RoleId,
            RoleName = roleName,
            IsActive = u.IsActive,
            CreatedAt = u.CreatedAt,
            LastLogin = u.LastLogin
        };
    }
}
