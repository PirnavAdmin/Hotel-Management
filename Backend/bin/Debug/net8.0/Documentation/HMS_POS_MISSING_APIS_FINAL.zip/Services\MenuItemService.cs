using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS.Services;

public class MenuItemService
{
    private readonly AppDbContext _context;

    public MenuItemService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<MenuItemResponseDto>> GetMenuItemsAsync(string? search = null, string? category = null, string? dietaryType = null)
    {
        var query = _context.MenuItems
            .Where(m => m.DeletedAt == null)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var searchLower = search.Trim().ToLower();
            query = query.Where(m =>
                m.DishName.ToLower().Contains(searchLower) ||
                (m.ShortDescription != null && m.ShortDescription.ToLower().Contains(searchLower)) ||
                m.Category.ToLower().Contains(searchLower));
        }

        if (!string.IsNullOrWhiteSpace(category))
        {
            var categoryLower = category.Trim().ToLower();
            query = query.Where(m => m.Category.ToLower() == categoryLower);
        }

        if (!string.IsNullOrWhiteSpace(dietaryType))
        {
            var dietaryLower = dietaryType.Trim().ToLower();
            query = query.Where(m => m.DietaryType.ToLower() == dietaryLower);
        }

        var items = await query
            .OrderByDescending(m => m.CreatedAt)
            .ToListAsync();

        return items.Select(MapToResponseDto).ToList();
    }

    public async Task<MenuItemResponseDto?> GetMenuItemByIdAsync(long id)
    {
        var item = await _context.MenuItems
            .FirstOrDefaultAsync(m => m.MenuItemId == id && m.DeletedAt == null);

        return item == null ? null : MapToResponseDto(item);
    }

    public async Task<MenuItemResponseDto> CreateMenuItemAsync(CreateMenuItemDto dto)
    {
        var item = new MenuItem
        {
            DishName = dto.DishName.Trim(),
            Category = dto.Category.Trim(),
            Price = dto.Price,
            DietaryType = dto.DietaryType.Trim().ToUpper(),
            SpiceLevel = dto.SpiceLevel,
            PrepTimeMinutes = dto.PrepTimeMinutes ?? 15,
            ShortDescription = dto.ShortDescription?.Trim(),
            ImageUrl = dto.ImageUrl?.Trim(),
            IsChefsSpecial = dto.IsChefsSpecial,
            IsAvailable = dto.IsAvailable,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.MenuItems.Add(item);
        await _context.SaveChangesAsync();

        return MapToResponseDto(item);
    }

    public async Task<MenuItemResponseDto?> UpdateMenuItemAsync(long id, UpdateMenuItemDto dto)
    {
        var item = await _context.MenuItems
            .FirstOrDefaultAsync(m => m.MenuItemId == id && m.DeletedAt == null);

        if (item == null) return null;

        item.DishName = dto.DishName.Trim();
        item.Category = dto.Category.Trim();
        item.Price = dto.Price;
        item.DietaryType = dto.DietaryType.Trim().ToUpper();
        item.SpiceLevel = dto.SpiceLevel;
        item.PrepTimeMinutes = dto.PrepTimeMinutes ?? 15;
        item.ShortDescription = dto.ShortDescription?.Trim();
        item.ImageUrl = dto.ImageUrl?.Trim();
        item.IsChefsSpecial = dto.IsChefsSpecial;
        item.IsAvailable = dto.IsAvailable;
        item.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return MapToResponseDto(item);
    }

    public async Task<bool> DeleteMenuItemAsync(long id)
    {
        var item = await _context.MenuItems
            .FirstOrDefaultAsync(m => m.MenuItemId == id && m.DeletedAt == null);

        if (item == null) return false;

        item.DeletedAt = DateTime.UtcNow;
        item.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<string>> GetCategoriesAsync()
    {
        return await _context.MenuItems
            .Where(m => m.DeletedAt == null)
            .Select(m => m.Category)
            .Distinct()
            .OrderBy(c => c)
            .ToListAsync();
    }

    public async Task<MenuCategory> CreateCategoryAsync(CreateCategoryRequest request)
    {
        var category = new MenuCategory
        {
            Id = Guid.NewGuid(),
            Name = request.Name.Trim(),
            DisplayOrder = request.DisplayOrder
        };

        _context.MenuCategories.Add(category);
        await _context.SaveChangesAsync();

        return category;
    }

    public async Task<MenuItemResponseDto?> ToggleAvailabilityAsync(long id, bool isAvailable)
    {
        var item = await _context.MenuItems
            .FirstOrDefaultAsync(m => m.MenuItemId == id && m.DeletedAt == null);

        if (item == null) return null;

        item.IsAvailable = isAvailable;
        item.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return MapToResponseDto(item);
    }

    private static MenuItemResponseDto MapToResponseDto(MenuItem item)
    {
        return new MenuItemResponseDto
        {
            MenuItemId = item.MenuItemId,
            DishName = item.DishName,
            Category = item.Category,
            Price = item.Price,
            DietaryType = item.DietaryType,
            SpiceLevel = item.SpiceLevel,
            PrepTimeMinutes = item.PrepTimeMinutes,
            ShortDescription = item.ShortDescription,
            ImageUrl = item.ImageUrl,
            IsChefsSpecial = item.IsChefsSpecial,
            IsAvailable = item.IsAvailable,
            CreatedAt = item.CreatedAt,
            UpdatedAt = item.UpdatedAt
        };
    }
}
