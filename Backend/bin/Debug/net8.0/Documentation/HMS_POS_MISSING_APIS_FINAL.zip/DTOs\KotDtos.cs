using System.ComponentModel.DataAnnotations;

namespace HMS.DTOs;

public class CreateKotOrderDto
{
    public long? TableId { get; set; }

    [Required(ErrorMessage = "Table Name is required.")]
    public string TableName { get; set; } = string.Empty;

    public string SectionArea { get; set; } = "Main Hall";

    [Required(ErrorMessage = "Server Name is required.")]
    public string ServerName { get; set; } = string.Empty;

    [Required(ErrorMessage = "At least one item is required.")]
    public List<CreateKotOrderItemDto> Items { get; set; } = new();
}

public class CreateKotOrderItemDto
{
    public long? MenuItemId { get; set; }

    [Required(ErrorMessage = "Dish Name is required.")]
    public string DishName { get; set; } = string.Empty;

    [Range(1, 100, ErrorMessage = "Quantity must be at least 1.")]
    public int Quantity { get; set; } = 1;
}

public class UpdateOrderStatusDto
{
    [Required(ErrorMessage = "Status is required.")]
    public string Status { get; set; } = "PREPARATION COMPLETED"; // "PENDING", "IN PREPARATION", "PREPARATION COMPLETED"
}

public class UpdateItemStatusDto
{
    [Required(ErrorMessage = "Status is required.")]
    public string Status { get; set; } = "READY"; // "PENDING", "IN PREP", "READY"
}

public class KotOrderResponseDto
{
    public long OrderId { get; set; }

    public long? TableId { get; set; }

    public string TableName { get; set; } = string.Empty;

    public string SectionArea { get; set; } = string.Empty;

    public string ServerName { get; set; } = string.Empty;

    public string OrderStatus { get; set; } = string.Empty;

    public DateTime OrderReceivedAt { get; set; }

    public string OrderReceivedFormatted { get; set; } = string.Empty; // e.g. "04:46 PM"

    public List<KotOrderItemResponseDto> Items { get; set; } = new();
}

public class KotOrderItemResponseDto
{
    public long OrderItemId { get; set; }

    public long OrderId { get; set; }

    public long? MenuItemId { get; set; }

    public string DishName { get; set; } = string.Empty;

    public int Quantity { get; set; }

    public string ItemStatus { get; set; } = string.Empty;
}

public class KotSummaryDto
{
    public int TotalTickets { get; set; }

    public int PendingTickets { get; set; }

    public int InPrepTickets { get; set; }

    public int ReadyTickets { get; set; }

    public int CancelledTickets { get; set; }

    public double AveragePrepTimeMinutes { get; set; }
}
