using System.ComponentModel.DataAnnotations;

namespace HMS.DTOs;

public class CreateTableDto
{
    [Required(ErrorMessage = "Table Name / Identifier is required.")]
    [MaxLength(50)]
    public string TableName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Dining Section / Area is required.")]
    [MaxLength(50)]
    public string SectionArea { get; set; } = "Main Hall";

    [Required(ErrorMessage = "Seating capacity chairs is required.")]
    [Range(1, 50, ErrorMessage = "Capacity must be between 1 and 50.")]
    public int CapacityChairs { get; set; } = 4;

    public long? AssignedServerId { get; set; }
}

public class UpdateTableDto
{
    [Required(ErrorMessage = "Table Name / Identifier is required.")]
    [MaxLength(50)]
    public string TableName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Dining Section / Area is required.")]
    [MaxLength(50)]
    public string SectionArea { get; set; } = "Main Hall";

    [Required(ErrorMessage = "Seating capacity chairs is required.")]
    [Range(1, 50, ErrorMessage = "Capacity must be between 1 and 50.")]
    public int CapacityChairs { get; set; } = 4;

    [Range(0, 50, ErrorMessage = "Occupied chairs must be non-negative.")]
    public int OccupiedChairs { get; set; } = 0;

    [Required(ErrorMessage = "Status is required.")]
    [MaxLength(20)]
    public string Status { get; set; } = "VACANT"; // "VACANT", "OCCUPIED", "RESERVED"

    public long? AssignedServerId { get; set; }
}

public class TableResponseDto
{
    public long TableId { get; set; }

    public string TableName { get; set; } = string.Empty;

    public string SectionArea { get; set; } = string.Empty;

    public int CapacityChairs { get; set; }

    public int OccupiedChairs { get; set; }

    public string Status { get; set; } = string.Empty;

    public long? AssignedServerId { get; set; }

    public string? AssignedServerName { get; set; }

    public string? AssignedServerRole { get; set; }

    public DateTime CreatedAt { get; set; }
}

public class TableSummaryDto
{
    public int TotalTables { get; set; }

    public int TotalChairs { get; set; }

    public int OccupiedChairs { get; set; }

    public int AvailableChairs { get; set; }
}
