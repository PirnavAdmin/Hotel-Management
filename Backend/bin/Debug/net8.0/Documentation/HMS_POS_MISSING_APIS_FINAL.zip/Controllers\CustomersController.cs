using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/customers")]
public class CustomersController : ControllerBase
{
    private readonly AppDbContext _context;

    public CustomersController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/customers
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetCustomers([FromQuery] string? search)
    {
        var query = _context.Customers.AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(c => c.FullName.Contains(term) || c.Phone.Contains(term) || (c.Email != null && c.Email.Contains(term)));
        }

        var customers = await query.OrderByDescending(c => c.CreatedAt).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Customers retrieved successfully.",
            count = customers.Count,
            data = customers
        });
    }

    // GET /api/v1/customers/{id}
    [AllowAnonymous]
    [HttpGet("{id:long}")]
    public async Task<IActionResult> GetCustomerById(long id)
    {
        var customer = await _context.Customers.FirstOrDefaultAsync(c => c.CustomerId == id);

        if (customer == null)
        {
            return NotFound(new { success = false, message = $"Customer with ID {id} not found." });
        }

        return Ok(new { success = true, data = customer });
    }

    // POST /api/v1/customers
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> CreateCustomer([FromBody] CustomerRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.FullName) || string.IsNullOrWhiteSpace(request.Phone))
        {
            return BadRequest(new { success = false, message = "Full Name and Phone are required." });
        }

        var customer = new Customer
        {
            FullName = request.FullName.Trim(),
            Phone = request.Phone.Trim(),
            Email = request.Email?.Trim(),
            LoyaltyPoints = request.LoyaltyPoints,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.Customers.Add(customer);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetCustomerById), new { id = customer.CustomerId }, new
        {
            success = true,
            message = "Customer created successfully.",
            data = customer
        });
    }

    // PUT /api/v1/customers/{id}
    [AllowAnonymous]
    [HttpPut("{id:long}")]
    public async Task<IActionResult> UpdateCustomer(long id, [FromBody] CustomerRequest request)
    {
        var customer = await _context.Customers.FirstOrDefaultAsync(c => c.CustomerId == id);

        if (customer == null)
        {
            return NotFound(new { success = false, message = $"Customer with ID {id} not found." });
        }

        if (!string.IsNullOrWhiteSpace(request.FullName)) customer.FullName = request.FullName.Trim();
        if (!string.IsNullOrWhiteSpace(request.Phone)) customer.Phone = request.Phone.Trim();
        if (request.Email != null) customer.Email = request.Email.Trim();
        customer.LoyaltyPoints = request.LoyaltyPoints;
        customer.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Customer details updated successfully.",
            data = customer
        });
    }
}

public class CustomerRequest
{
    public string FullName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? Email { get; set; }
    public int LoyaltyPoints { get; set; } = 0;
}
