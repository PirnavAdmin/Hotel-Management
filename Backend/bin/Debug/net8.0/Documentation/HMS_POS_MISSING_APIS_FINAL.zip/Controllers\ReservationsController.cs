using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/reservations")]
public class ReservationsController : ControllerBase
{
    private readonly AppDbContext _context;

    public ReservationsController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/reservations
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetReservations([FromQuery] string? status)
    {
        var query = _context.Reservations.AsQueryable();

        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(r => r.Status.ToUpper() == status.Trim().ToUpper());
        }

        var reservations = await query.OrderByDescending(r => r.ReservationTime).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Reservations retrieved successfully.",
            count = reservations.Count,
            data = reservations
        });
    }

    // POST /api/v1/reservations
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> CreateReservation([FromBody] CreateReservationRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.CustomerName) || string.IsNullOrWhiteSpace(request.Phone))
        {
            return BadRequest(new { success = false, message = "Customer Name and Phone are required." });
        }

        var reservation = new Reservation
        {
            CustomerId = request.CustomerId,
            CustomerName = request.CustomerName.Trim(),
            Phone = request.Phone.Trim(),
            TableId = request.TableId,
            GuestsCount = request.GuestsCount > 0 ? request.GuestsCount : 2,
            ReservationTime = request.ReservationTime != default ? request.ReservationTime : DateTime.UtcNow.AddHours(2),
            Status = "CONFIRMED",
            CreatedAt = DateTime.UtcNow
        };

        _context.Reservations.Add(reservation);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Reservation created successfully.",
            data = reservation
        });
    }

    // PUT /api/v1/reservations/{id}/status
    [AllowAnonymous]
    [HttpPut("{id:long}/status")]
    public async Task<IActionResult> UpdateReservationStatus(long id, [FromBody] UpdateReservationStatusRequest request)
    {
        var reservation = await _context.Reservations.FirstOrDefaultAsync(r => r.ReservationId == id);

        if (reservation == null)
        {
            return NotFound(new { success = false, message = $"Reservation with ID {id} not found." });
        }

        if (string.IsNullOrWhiteSpace(request.Status))
        {
            return BadRequest(new { success = false, message = "Status is required." });
        }

        reservation.Status = request.Status.Trim().ToUpper();
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Reservation status updated successfully.",
            data = reservation
        });
    }
}

public class CreateReservationRequest
{
    public long? CustomerId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public long? TableId { get; set; }
    public int GuestsCount { get; set; } = 2;
    public DateTime ReservationTime { get; set; }
}

public class UpdateReservationStatusRequest
{
    public string Status { get; set; } = "CONFIRMED";
}
