namespace HMS.DTOs;

public class CreateOrderRequest
{
    public long TableId { get; set; }

    public string ServerName { get; set; } = string.Empty;

    public int Guests { get; set; } = 1;

    public List<OrderItemInput> Items { get; set; } = new();
}

public class OrderItemInput
{
    public long MenuItemId { get; set; }

    public long? VariantId { get; set; }

    public string Name { get; set; } = string.Empty;

    public decimal Price { get; set; }

    public int Quantity { get; set; } = 1;

    public string? Notes { get; set; }
}

public class UpdateOrderItemsRequest
{
    public List<OrderItemInput> Items { get; set; } = new();
}

public class SettleOrderRequest
{
    public decimal DiscountPercent { get; set; }

    public bool ServiceChargeEnabled { get; set; }

    public decimal TipAmount { get; set; }

    public string? PaymentMethod { get; set; }
}

public class OrderDto
{
    public long Id { get; set; }

    public long TableId { get; set; }

    public string TableName { get; set; } = string.Empty;

    public string Section { get; set; } = string.Empty;

    public string ServerName { get; set; } = string.Empty;

    public int Guests { get; set; }

    public string Status { get; set; } = string.Empty;

    public decimal Subtotal { get; set; }

    public decimal DiscountPercent { get; set; }

    public decimal DiscountAmount { get; set; }

    public decimal TaxPercent { get; set; }

    public decimal TaxAmount { get; set; }

    public decimal ServiceChargePercent { get; set; }

    public decimal ServiceChargeAmount { get; set; }

    public decimal TipAmount { get; set; }

    public decimal GrandTotal { get; set; }

    public string? PaymentMethod { get; set; }

    public string? InvoiceNo { get; set; }

    public DateTime? SettledAt { get; set; }

    public DateTime CreatedAt { get; set; }

    public List<OrderItemDto> Items { get; set; } = new();
}

public class OrderItemDto
{
    public long Id { get; set; }

    public long OrderId { get; set; }

    public long MenuItemId { get; set; }

    public string Name { get; set; } = string.Empty;

    public decimal Price { get; set; }

    public int Quantity { get; set; }

    public string? Notes { get; set; }

    public string KotStatus { get; set; } = "Queued";

    public int KotBatch { get; set; }
}