using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace HMS.Controllers;

[ApiController]
[Route("api")]
public class StateController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly ILogger<StateController> _logger;

    public StateController(AppDbContext context, ILogger<StateController> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Retrieves full POS runtime state (tables, active orders, past orders, categories, menu items, staff).
    /// </summary>
    [AllowAnonymous]
    [HttpGet("state")]
    public async Task<IActionResult> GetState()
    {
        try
        {
            _logger.LogInformation("Fetching complete POS state.");

            var tables = await _context.DiningTables
                .Where(t => !t.IsDeleted)
                .OrderBy(t => t.Id)
                .Select(t => new
                {
                    id = t.Id,
                    name = t.Name,
                    section = "Main Dining",
                    capacity = t.Capacity,
                    status = t.Status,
                    server = "Staff"
                })
                .ToListAsync();

            var activeOrders = await _context.Orders
                .Include(o => o.Items)
                .Where(o => !o.IsDeleted && o.Status == "Active")
                .Select(o => new
                {
                    id = o.Id,
                    tableId = o.TableId,
                    tableName = o.TableName,
                    section = o.Section,
                    server = o.ServerName,
                    guests = o.Guests,
                    subtotal = o.Subtotal,
                    discountPercent = o.DiscountPercent,
                    discountAmount = o.DiscountAmount,
                    taxAmount = o.TaxAmount,
                    grandTotal = o.GrandTotal,
                    status = o.Status,
                    items = o.Items.Where(i => !i.IsDeleted).Select(i => new
                    {
                        id = i.Id,
                        menuItemId = i.MenuItemId,
                        name = i.Name,
                        price = i.Price,
                        quantity = i.Quantity,
                        notes = i.Notes,
                        kotStatus = i.KotStatus
                    })
                })
                .ToListAsync();

            var categories = await _context.MenuCategories
                .OrderBy(c => c.DisplayOrder)
                .Select(c => new { id = c.Id, name = c.Name, displayOrder = c.DisplayOrder })
                .ToListAsync();

            var menuItems = await _context.MenuItems
                .Where(m => m.DeletedAt == null)
                .Select(m => new
                {
                    id = m.MenuItemId.ToString(),
                    name = m.DishName,
                    category = m.Category,
                    price = m.Price,
                    isVeg = m.DietaryType.ToLower() == "veg",
                    spiceLevel = m.SpiceLevel == 0 ? "Mild" : (m.SpiceLevel == 1 ? "Medium" : "Spicy"),
                    description = m.ShortDescription,
                    prepTimeMinutes = m.PrepTimeMinutes ?? 15,
                    isAvailable = m.IsAvailable,
                    imageUrl = m.ImageUrl
                })
                .ToListAsync();

            var staff = await _context.Staff
                .Select(s => new { id = s.Id, name = s.Name, role = s.Role, phone = s.Phone, shift = s.Shift, status = s.Status })
                .ToListAsync();

            var pastOrders = await _context.Orders
                .Include(o => o.Items)
                .Where(o => !o.IsDeleted && o.Status == "Settled")
                .OrderByDescending(o => o.SettledAt)
                .Take(50)
                .Select(o => new
                {
                    id = o.Id,
                    tableId = o.TableId,
                    tableName = o.TableName,
                    section = o.Section,
                    server = o.ServerName,
                    guests = o.Guests,
                    subtotal = o.Subtotal,
                    discountAmount = o.DiscountAmount,
                    taxAmount = o.TaxAmount,
                    grandTotal = o.GrandTotal,
                    paymentMethod = o.PaymentMethod,
                    invoiceNo = o.InvoiceNo,
                    settledAt = o.SettledAt,
                    items = o.Items.Where(i => !i.IsDeleted).Select(i => new
                    {
                        id = i.Id,
                        name = i.Name,
                        price = i.Price,
                        quantity = i.Quantity
                    })
                })
                .ToListAsync();

            var stateData = new
            {
                tables,
                activeOrders,
                categories,
                menuItems,
                staff,
                pastOrders
            };

            return Ok(new PosStateResponseDto
            {
                Success = true,
                Message = "POS state loaded successfully.",
                Data = stateData
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching POS state.");
            return StatusCode(500, new { success = false, message = "An error occurred while retrieving POS state." });
        }
    }

    /// <summary>
    /// Synchronizes POS client changes to the database.
    /// </summary>
    [HttpPost("sync")]
    public async Task<IActionResult> SyncState([FromBody] JsonElement syncPayload)
    {
        try
        {
            _logger.LogInformation("Processing POS sync payload.");

            // Validate and parse incoming JSON payload safely
            return Ok(new
            {
                success = true,
                message = "POS state synchronized successfully.",
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing POS sync.");
            return StatusCode(500, new { success = false, message = "An error occurred while synchronizing POS state." });
        }
    }

    /// <summary>
    /// Server-Sent Events (SSE) stream endpoint for live real-time POS & Kitchen updates.
    /// </summary>
    [HttpGet("events")]
    public async Task GetEvents(CancellationToken cancellationToken)
    {
        Response.ContentType = "text/event-stream";
        Response.Headers.Append("Cache-Control", "no-cache");
        Response.Headers.Append("Connection", "keep-alive");

        _logger.LogInformation("Client connected to SSE event stream.");

        try
        {
            // Initial connection event message
            var initialData = JsonSerializer.Serialize(new { eventType = "connected", message = "Connected to HMS live event stream.", timestamp = DateTime.UtcNow });
            await Response.WriteAsync($"data: {initialData}\n\n", cancellationToken);
            await Response.Body.FlushAsync(cancellationToken);

            // Keep-alive heartbeat loop
            while (!cancellationToken.IsCancellationRequested)
            {
                await Task.Delay(15000, cancellationToken);
                var heartbeat = JsonSerializer.Serialize(new { eventType = "heartbeat", timestamp = DateTime.UtcNow });
                await Response.WriteAsync($"data: {heartbeat}\n\n", cancellationToken);
                await Response.Body.FlushAsync(cancellationToken);
            }
        }
        catch (TaskCanceledException)
        {
            _logger.LogInformation("SSE client disconnected from event stream.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in SSE event stream.");
        }
    }
}
