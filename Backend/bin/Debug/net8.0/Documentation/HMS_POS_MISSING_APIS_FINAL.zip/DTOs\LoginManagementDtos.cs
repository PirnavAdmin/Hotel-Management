using System.ComponentModel.DataAnnotations;

namespace HMS.DTOs;

public class CreateLoginDto
{
    [Required(ErrorMessage = "Account Role is required.")]
    public string AccountRole { get; set; } = string.Empty; // "User POS" or "Kitchen KOT"

    [Required(ErrorMessage = "Display Name is required.")]
    [MaxLength(100)]
    public string DisplayName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Username is required.")]
    [MaxLength(60)]
    public string UserName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required.")]
    [MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
    public string Password { get; set; } = string.Empty;

    [EmailAddress]
    public string? Email { get; set; }

    public string? Phone { get; set; }
}

public class UserAccountDto
{
    public long UserId { get; set; }

    public string FullName { get; set; } = string.Empty;

    public string UserName { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string? Phone { get; set; }

    public long RoleId { get; set; }

    public string RoleName { get; set; } = string.Empty;

    public bool IsActive { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? LastLogin { get; set; }
}

public class LoginManagementSummaryDto
{
    public int PosUsersCount { get; set; }

    public int KotUsersCount { get; set; }

    public int AdminsCount { get; set; }

    public List<UserAccountDto> PosUsers { get; set; } = new();

    public List<UserAccountDto> KotUsers { get; set; } = new();

    public List<UserAccountDto> Admins { get; set; } = new();
}
