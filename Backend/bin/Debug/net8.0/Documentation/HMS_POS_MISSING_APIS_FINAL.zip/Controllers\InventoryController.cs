using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/inventory")]
public class InventoryController : ControllerBase
{
    private readonly AppDbContext _context;

    public InventoryController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/inventory/ingredients
    [AllowAnonymous]
    [HttpGet("ingredients")]
    public async Task<IActionResult> GetIngredients()
    {
        var ingredients = await _context.Ingredients.OrderBy(i => i.Name).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Ingredients stock list retrieved successfully.",
            count = ingredients.Count,
            data = ingredients
        });
    }

    // GET /api/v1/inventory/low-stock
    [AllowAnonymous]
    [HttpGet("low-stock")]
    public async Task<IActionResult> GetLowStockAlerts()
    {
        var lowStock = await _context.Ingredients
            .Where(i => i.CurrentStock <= i.MinimumThreshold)
            .OrderBy(i => i.CurrentStock)
            .ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Low stock ingredients retrieved successfully.",
            count = lowStock.Count,
            data = lowStock
        });
    }

    // POST /api/v1/inventory/ingredients
    [AllowAnonymous]
    [HttpPost("ingredients")]
    public async Task<IActionResult> CreateIngredient([FromBody] CreateIngredientRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { success = false, message = "Ingredient Name is required." });
        }

        var ingredient = new Ingredient
        {
            Name = request.Name.Trim(),
            Unit = string.IsNullOrWhiteSpace(request.Unit) ? "KG" : request.Unit.Trim().ToUpper(),
            CurrentStock = request.CurrentStock,
            MinimumThreshold = request.MinimumThreshold > 0 ? request.MinimumThreshold : 5.00m,
            UnitCost = request.UnitCost,
            UpdatedAt = DateTime.UtcNow
        };

        _context.Ingredients.Add(ingredient);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Ingredient added to inventory successfully.",
            data = ingredient
        });
    }

    // POST /api/v1/inventory/adjust
    [AllowAnonymous]
    [HttpPost("adjust")]
    public async Task<IActionResult> AdjustStock([FromBody] StockAdjustmentRequest request)
    {
        var ingredient = await _context.Ingredients.FirstOrDefaultAsync(i => i.IngredientId == request.IngredientId);

        if (ingredient == null)
        {
            return NotFound(new { success = false, message = $"Ingredient with ID {request.IngredientId} not found." });
        }

        if (request.QuantityChange == 0)
        {
            return BadRequest(new { success = false, message = "Quantity change cannot be zero." });
        }

        ingredient.CurrentStock += request.QuantityChange;
        if (ingredient.CurrentStock < 0) ingredient.CurrentStock = 0;
        ingredient.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Stock adjusted successfully.",
            data = ingredient
        });
    }
}

public class CreateIngredientRequest
{
    public string Name { get; set; } = string.Empty;
    public string Unit { get; set; } = "KG";
    public decimal CurrentStock { get; set; }
    public decimal MinimumThreshold { get; set; } = 5.00m;
    public decimal UnitCost { get; set; }
}

public class StockAdjustmentRequest
{
    public long IngredientId { get; set; }
    public decimal QuantityChange { get; set; }
    public string? Reason { get; set; } // "RESTOCK", "WASTAGE", "CORRECTION"
}
