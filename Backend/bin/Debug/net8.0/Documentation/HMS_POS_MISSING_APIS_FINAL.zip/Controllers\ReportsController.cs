namespace HMS.Controllers;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HMS.Data;
using HMS.DTOs;

[ApiController]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly AppDbContext _context;

    public ReportsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet("dashboard")]
    public async Task<IActionResult> GetDashboardReport()
    {
        var today = DateTime.UtcNow.Date;

        var todayOrders = await _context.Orders
            .Include(o => o.Items)
            .Where(o => o.CreatedAt >= today || (o.SettledAt.HasValue && o.SettledAt.Value >= today))
            .ToListAsync();

        var settledOrders = todayOrders.Where(o => o.Status == "settled").ToList();

        decimal todayRevenue = settledOrders.Sum(o => o.GrandTotal);
        int totalOrdersCount = todayOrders.Count;
        int settledOrdersCount = settledOrders.Count;
        int activeTablesCount = await _context.DiningTables.CountAsync(t => t.Status == "occupied" || t.Status == "billed");
        decimal avgOrderValue = settledOrdersCount > 0 ? Math.Round(todayRevenue / settledOrdersCount, 2) : 0;

        // Top Selling Dishes
        var topSellingDishes = todayOrders
            .SelectMany(o => o.Items)
            .GroupBy(i => i.Name)
            .Select(g => new TopSellingDishDto
            {
                ItemName = g.Key,
                QuantitySold = g.Sum(i => i.Quantity),
                TotalRevenue = g.Sum(i => i.Price * i.Quantity)
            })
            .OrderByDescending(d => d.QuantitySold)
            .Take(5)
            .ToList();

        // Payment Method Breakdown
        var paymentMethodBreakdown = settledOrders
            .Where(o => !string.IsNullOrEmpty(o.PaymentMethod))
            .GroupBy(o => o.PaymentMethod!)
            .ToDictionary(g => g.Key, g => g.Sum(o => o.GrandTotal));

        // Category Sales Breakdown
        var categorySales = new Dictionary<string, int>();
        var allItemsWithCat = await _context.OrderItems
            .Include(oi => oi.Order)
            .Where(oi => oi.Order != null && (oi.Order.CreatedAt >= today || (oi.Order.SettledAt.HasValue && oi.Order.SettledAt.Value >= today)))
            .ToListAsync();

        return Ok(new DashboardReportDto
        {
            TodayRevenue = todayRevenue,
            TodayTotalOrders = totalOrdersCount,
            TodaySettledOrders = settledOrdersCount,
            ActiveTablesCount = activeTablesCount,
            AverageOrderValue = avgOrderValue,
            TopSellingDishes = topSellingDishes,
            PaymentMethodBreakdown = paymentMethodBreakdown,
            CategorySalesBreakdown = categorySales
        });
    }
}
