using System.ComponentModel.DataAnnotations;

namespace HMS.DTOs;

public class CreateStaffDto
{
    [Required(ErrorMessage = "Full Name is required.")]
    [MaxLength(100)]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Role / Designation title is required.")]
    [MaxLength(50)]
    public string RoleTitle { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone number is required.")]
    [MaxLength(20)]
    public string Phone { get; set; } = string.Empty;

    [Required(ErrorMessage = "Shift description is required.")]
    [MaxLength(50)]
    public string Shift { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;
}

public class UpdateStaffDto
{
    [Required(ErrorMessage = "Full Name is required.")]
    [MaxLength(100)]
    public string FullName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Role / Designation title is required.")]
    [MaxLength(50)]
    public string RoleTitle { get; set; } = string.Empty;

    [Required(ErrorMessage = "Phone number is required.")]
    [MaxLength(20)]
    public string Phone { get; set; } = string.Empty;

    [Required(ErrorMessage = "Shift description is required.")]
    [MaxLength(50)]
    public string Shift { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;
}

public class StaffResponseDto
{
    public long StaffId { get; set; }

    public string FullName { get; set; } = string.Empty;

    public string RoleTitle { get; set; } = string.Empty;

    public string Phone { get; set; } = string.Empty;

    public string Shift { get; set; } = string.Empty;

    public bool IsActive { get; set; }

    public int AssignedTablesCount { get; set; }

    public string AvatarInitial { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; }
}
