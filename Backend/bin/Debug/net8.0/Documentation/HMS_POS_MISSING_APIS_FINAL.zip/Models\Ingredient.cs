using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HMS.Models;

[Table("ingredients")]
public class Ingredient
{
    [Key]
    [Column("ingredient_id")]
    public long IngredientId { get; set; }

    [Required]
    [MaxLength(100)]
    [Column("name")]
    public string Name { get; set; } = string.Empty;

    [Required]
    [MaxLength(20)]
    [Column("unit")]
    public string Unit { get; set; } = "KG"; // "KG", "LTR", "PCS", "GRAM"

    [Column("current_stock", TypeName = "decimal(18,2)")]
    public decimal CurrentStock { get; set; }

    [Column("minimum_threshold", TypeName = "decimal(18,2)")]
    public decimal MinimumThreshold { get; set; } = 5.00m;

    [Column("unit_cost", TypeName = "decimal(18,2)")]
    public decimal UnitCost { get; set; }

    [Column("updated_at")]
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
