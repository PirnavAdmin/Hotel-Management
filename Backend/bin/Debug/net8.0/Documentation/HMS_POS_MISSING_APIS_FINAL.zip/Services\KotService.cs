using HMS.Data;
using HMS.DTOs;
using HMS.Models;
using Microsoft.EntityFrameworkCore;

namespace HMS.Services;

public class KotService
{
    private readonly AppDbContext _context;

    public KotService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<KotOrderResponseDto>> GetActiveKotOrdersAsync(long? tableId = null, string? status = null)
    {
        var query = _context.KotOrders
            .Include(o => o.Items)
            .Where(o => o.DeletedAt == null)
            .AsQueryable();

        if (tableId.HasValue && tableId.Value > 0)
        {
            query = query.Where(o => o.TableId == tableId.Value);
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            var statusUpper = status.Trim().ToUpper();
            query = query.Where(o => o.OrderStatus.ToUpper() == statusUpper);
        }

        var orders = await query
            .OrderByDescending(o => o.OrderReceivedAt)
            .ToListAsync();

        return orders.Select(MapToResponseDto).ToList();
    }

    public async Task<KotOrderResponseDto?> GetKotOrderByIdAsync(long orderId)
    {
        var order = await _context.KotOrders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.OrderId == orderId && o.DeletedAt == null);

        return order == null ? null : MapToResponseDto(order);
    }

    public async Task<KotOrderResponseDto> CreateKotOrderAsync(CreateKotOrderDto dto)
    {
        var order = new KotOrder
        {
            TableId = dto.TableId,
            TableName = dto.TableName.Trim(),
            SectionArea = string.IsNullOrWhiteSpace(dto.SectionArea) ? "Main Hall" : dto.SectionArea.Trim(),
            ServerName = dto.ServerName.Trim(),
            OrderStatus = "PENDING",
            OrderReceivedAt = DateTime.UtcNow,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow,
            Items = dto.Items.Select(i => new KotOrderItem
            {
                MenuItemId = i.MenuItemId,
                DishName = i.DishName.Trim(),
                Quantity = i.Quantity > 0 ? i.Quantity : 1,
                ItemStatus = "PENDING",
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            }).ToList()
        };

        _context.KotOrders.Add(order);
        await _context.SaveChangesAsync();

        return MapToResponseDto(order);
    }

    public async Task<KotOrderResponseDto?> UpdateOrderStatusAsync(long orderId, string status)
    {
        var order = await _context.KotOrders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.OrderId == orderId && o.DeletedAt == null);

        if (order == null) return null;

        var newStatus = status.Trim().ToUpper();
        order.OrderStatus = newStatus;
        order.UpdatedAt = DateTime.UtcNow;

        // If whole order marked PREPARATION COMPLETED or READY, update item statuses
        if (newStatus == "PREPARATION COMPLETED" || newStatus == "READY")
        {
            foreach (var item in order.Items)
            {
                item.ItemStatus = "READY";
                item.UpdatedAt = DateTime.UtcNow;
            }
        }

        await _context.SaveChangesAsync();
        return MapToResponseDto(order);
    }

    public async Task<KotOrderResponseDto?> UpdateItemStatusAsync(long orderId, long itemId, string status)
    {
        var order = await _context.KotOrders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.OrderId == orderId && o.DeletedAt == null);

        if (order == null) return null;

        var item = order.Items.FirstOrDefault(i => i.OrderItemId == itemId);
        if (item == null) return null;

        item.ItemStatus = status.Trim().ToUpper();
        item.UpdatedAt = DateTime.UtcNow;

        // Auto-update overall order status if all items are ready
        if (order.Items.All(i => i.ItemStatus.ToUpper() == "READY"))
        {
            order.OrderStatus = "PREPARATION COMPLETED";
        }
        else if (order.Items.Any(i => i.ItemStatus.ToUpper() == "IN PREP" || i.ItemStatus.ToUpper() == "READY"))
        {
            order.OrderStatus = "IN PREPARATION";
        }

        order.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        return MapToResponseDto(order);
    }

    public async Task<bool> DeleteKotOrderAsync(long orderId)
    {
        var order = await _context.KotOrders
            .FirstOrDefaultAsync(o => o.OrderId == orderId && o.DeletedAt == null);

        if (order == null) return false;

        order.DeletedAt = DateTime.UtcNow;
        order.OrderStatus = "CANCELLED";
        order.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<KotSummaryDto> GetKotSummaryAsync()
    {
        var allOrders = await _context.KotOrders
            .Include(o => o.Items)
            .Where(o => o.DeletedAt == null)
            .ToListAsync();

        return new KotSummaryDto
        {
            TotalTickets = allOrders.Count,
            PendingTickets = allOrders.Count(o => o.OrderStatus.Equals("PENDING", StringComparison.OrdinalIgnoreCase)),
            InPrepTickets = allOrders.Count(o => o.OrderStatus.Equals("IN PREPARATION", StringComparison.OrdinalIgnoreCase)),
            ReadyTickets = allOrders.Count(o => o.OrderStatus.Equals("PREPARATION COMPLETED", StringComparison.OrdinalIgnoreCase) || o.OrderStatus.Equals("READY", StringComparison.OrdinalIgnoreCase)),
            CancelledTickets = _context.KotOrders.Count(o => o.DeletedAt != null || o.OrderStatus == "CANCELLED"),
            AveragePrepTimeMinutes = 15.0
        };
    }

    public async Task<KotOrderResponseDto?> MarkAllPreparedAsync(long orderId)
    {
        var order = await _context.KotOrders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.OrderId == orderId && o.DeletedAt == null);

        if (order == null) return null;

        order.OrderStatus = "PREPARATION COMPLETED";
        order.UpdatedAt = DateTime.UtcNow;

        foreach (var item in order.Items)
        {
            item.ItemStatus = "READY";
            item.UpdatedAt = DateTime.UtcNow;
        }

        await _context.SaveChangesAsync();
        return MapToResponseDto(order);
    }

    public async Task<KotOrderResponseDto?> AdvanceItemStatusAsync(long orderId, long itemId)
    {
        var order = await _context.KotOrders
            .Include(o => o.Items)
            .FirstOrDefaultAsync(o => o.OrderId == orderId && o.DeletedAt == null);

        if (order == null) return null;

        var item = order.Items.FirstOrDefault(i => i.OrderItemId == itemId);
        if (item == null) return null;

        var currentStatus = item.ItemStatus.ToUpper().Trim();
        if (currentStatus == "PENDING")
        {
            item.ItemStatus = "IN PREP";
        }
        else
        {
            item.ItemStatus = "READY";
        }

        item.UpdatedAt = DateTime.UtcNow;

        if (order.Items.All(i => i.ItemStatus.ToUpper() == "READY"))
        {
            order.OrderStatus = "PREPARATION COMPLETED";
        }
        else if (order.Items.Any(i => i.ItemStatus.ToUpper() == "IN PREP" || i.ItemStatus.ToUpper() == "READY"))
        {
            order.OrderStatus = "IN PREPARATION";
        }

        order.UpdatedAt = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        return MapToResponseDto(order);
    }

    private static KotOrderResponseDto MapToResponseDto(KotOrder o)
    {
        return new KotOrderResponseDto
        {
            OrderId = o.OrderId,
            TableId = o.TableId,
            TableName = o.TableName,
            SectionArea = o.SectionArea,
            ServerName = o.ServerName,
            OrderStatus = o.OrderStatus,
            OrderReceivedAt = o.OrderReceivedAt,
            OrderReceivedFormatted = o.OrderReceivedAt.ToString("hh:mm tt"),
            Items = o.Items.Select(i => new KotOrderItemResponseDto
            {
                OrderItemId = i.OrderItemId,
                OrderId = i.OrderId,
                MenuItemId = i.MenuItemId,
                DishName = i.DishName,
                Quantity = i.Quantity,
                ItemStatus = i.ItemStatus
            }).ToList()
        };
    }
}
