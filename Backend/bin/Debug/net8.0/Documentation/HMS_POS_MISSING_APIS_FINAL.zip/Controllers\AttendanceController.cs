using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/employees/attendance")]
public class AttendanceController : ControllerBase
{
    private readonly AppDbContext _context;

    public AttendanceController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/employees/attendance
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetAttendanceLogs([FromQuery] long? staffId)
    {
        var query = _context.Attendances.AsQueryable();

        if (staffId.HasValue && staffId.Value > 0)
        {
            query = query.Where(a => a.StaffId == staffId.Value);
        }

        var logs = await query.OrderByDescending(a => a.CheckIn).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Attendance logs retrieved successfully.",
            count = logs.Count,
            data = logs
        });
    }

    // POST /api/v1/employees/attendance/check-in
    [AllowAnonymous]
    [HttpPost("check-in")]
    public async Task<IActionResult> CheckIn([FromBody] CheckInRequest request)
    {
        if (request.StaffId <= 0)
        {
            return BadRequest(new { success = false, message = "Valid Staff ID is required." });
        }

        var attendance = new Attendance
        {
            StaffId = request.StaffId,
            CheckIn = DateTime.UtcNow,
            Status = "PRESENT",
            Shift = string.IsNullOrWhiteSpace(request.Shift) ? "Morning Shift" : request.Shift.Trim()
        };

        _context.Attendances.Add(attendance);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Employee checked in successfully.",
            data = attendance
        });
    }

    // POST /api/v1/employees/attendance/check-out
    [AllowAnonymous]
    [HttpPost("check-out")]
    public async Task<IActionResult> CheckOut([FromBody] CheckOutRequest request)
    {
        var attendance = await _context.Attendances
            .FirstOrDefaultAsync(a => a.AttendanceId == request.AttendanceId || (a.StaffId == request.StaffId && a.CheckOut == null));

        if (attendance == null)
        {
            return NotFound(new { success = false, message = "Active attendance record not found for check-out." });
        }

        attendance.CheckOut = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Employee checked out successfully.",
            data = attendance
        });
    }
}

public class CheckInRequest
{
    public long StaffId { get; set; }
    public string? Shift { get; set; }
}

public class CheckOutRequest
{
    public long AttendanceId { get; set; }
    public long StaffId { get; set; }
}
