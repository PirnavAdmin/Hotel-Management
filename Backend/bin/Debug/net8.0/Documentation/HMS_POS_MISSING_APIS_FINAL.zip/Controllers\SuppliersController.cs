using HMS.Data;
using HMS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HMS.Controllers;

[ApiController]
[Route("api/v1/suppliers")]
public class SuppliersController : ControllerBase
{
    private readonly AppDbContext _context;

    public SuppliersController(AppDbContext context)
    {
        _context = context;
    }

    // GET /api/v1/suppliers
    [AllowAnonymous]
    [HttpGet]
    public async Task<IActionResult> GetSuppliers()
    {
        var suppliers = await _context.Suppliers.Where(s => s.IsActive).OrderBy(s => s.SupplierName).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Suppliers retrieved successfully.",
            count = suppliers.Count,
            data = suppliers
        });
    }

    // POST /api/v1/suppliers
    [AllowAnonymous]
    [HttpPost]
    public async Task<IActionResult> CreateSupplier([FromBody] CreateSupplierRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.SupplierName) || string.IsNullOrWhiteSpace(request.Phone))
        {
            return BadRequest(new { success = false, message = "Supplier Name and Phone are required." });
        }

        var supplier = new Supplier
        {
            SupplierName = request.SupplierName.Trim(),
            Phone = request.Phone.Trim(),
            Email = request.Email?.Trim(),
            Address = request.Address?.Trim(),
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        _context.Suppliers.Add(supplier);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Supplier registered successfully.",
            data = supplier
        });
    }

    // GET /api/v1/suppliers/purchase-orders
    [AllowAnonymous]
    [HttpGet("purchase-orders")]
    public async Task<IActionResult> GetPurchaseOrders([FromQuery] string? status)
    {
        var query = _context.PurchaseOrders.AsQueryable();

        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(po => po.Status.ToUpper() == status.Trim().ToUpper());
        }

        var pos = await query.OrderByDescending(po => po.CreatedAt).ToListAsync();

        return Ok(new
        {
            success = true,
            message = "Purchase orders retrieved successfully.",
            count = pos.Count,
            data = pos
        });
    }

    // POST /api/v1/suppliers/purchase-orders
    [AllowAnonymous]
    [HttpPost("purchase-orders")]
    public async Task<IActionResult> CreatePurchaseOrder([FromBody] CreatePurchaseOrderRequest request)
    {
        if (request.SupplierId <= 0 || request.TotalAmount <= 0)
        {
            return BadRequest(new { success = false, message = "Valid Supplier ID and Total Amount are required." });
        }

        var po = new PurchaseOrder
        {
            SupplierId = request.SupplierId,
            PoNumber = $"PO-{DateTime.UtcNow:yyyyMMdd}-{Random.Shared.Next(1000, 9999)}",
            TotalAmount = request.TotalAmount,
            Status = "PENDING",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _context.PurchaseOrders.Add(po);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Purchase order created successfully.",
            data = po
        });
    }

    // PUT /api/v1/suppliers/purchase-orders/{id}/status
    [AllowAnonymous]
    [HttpPut("purchase-orders/{id:long}/status")]
    public async Task<IActionResult> UpdatePoStatus(long id, [FromBody] UpdatePoStatusRequest request)
    {
        var po = await _context.PurchaseOrders.FirstOrDefaultAsync(p => p.PoId == id);

        if (po == null)
        {
            return NotFound(new { success = false, message = $"Purchase Order with ID {id} not found." });
        }

        if (string.IsNullOrWhiteSpace(request.Status))
        {
            return BadRequest(new { success = false, message = "Status is required." });
        }

        po.Status = request.Status.Trim().ToUpper();
        po.UpdatedAt = DateTime.UtcNow;

        await _context.SaveChangesAsync();

        return Ok(new
        {
            success = true,
            message = "Purchase order status updated successfully.",
            data = po
        });
    }
}

public class CreateSupplierRequest
{
    public string SupplierName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Address { get; set; }
}

public class CreatePurchaseOrderRequest
{
    public long SupplierId { get; set; }
    public decimal TotalAmount { get; set; }
}

public class UpdatePoStatusRequest
{
    public string Status { get; set; } = "RECEIVED";
}
